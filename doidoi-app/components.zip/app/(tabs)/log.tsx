import { View, Text } from 'react-native'
import React from 'react'

const log = () => {
  return (
    <View>
      <Text>log</Text>
    </View>
  )
}

export default log