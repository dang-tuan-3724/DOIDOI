import { View, Text } from 'react-native'
import React from 'react'

const device = () => {
  return (
    <View>
      <Text>device</Text>
    </View>
  )
}

export default device